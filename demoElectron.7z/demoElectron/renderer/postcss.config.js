module.exports = {
plugins: [
require('tailwindcss'), // ← v3 の公式プラグイン
require('autoprefixer'),
],
};